function check_loginG(){
	var email = document.getElementById('ms_mail').value;
	var email_p = email.split('@');
	
	if(email.length < 8){
		alert("O E-mail informado não está correto!\nTente novamente!");
		document.getElementById('ms_mail').focus();
		return false;
	}
	if(email_p[1] != 'gmail.com'){
		alert("O E-mail informado não é válido.\nTente novamente!\nEx.: nome@gmail.com");
		document.getElementById('ms_mail').focus();
		return false;
	}

}

function check_password(){
	var senha_now = document.getElementById('ms_pass').value;

	if(senha_now.length < 6 || senha_now.length > 25){
		alert("A senha informada não pertece a este e-mail ou está incorreta.\nTente novamente!");
		document.getElementById('ms_pass').focus();
		return false;
	}
}